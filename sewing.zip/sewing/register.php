<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } else {
        $hashed_password =md5($password);
        $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
        if (mysqli_query($conn, $query)) {
            header("Location: login.php");
            exit();
        } else {
            $error = "Error: " . mysqli_error($con);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>Register | Annai Agency</title>
<link rel="stylesheet" href="./assets/css/login.css">
</head>

<body>
<div class="container">
<h2>Register</h2>
<?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
<form method="POST" action="">
<label>Username:</label>
<input type="text" name="username" required>

<label>Email:</label>
<input type="email" name="email" required>

<label>Password:</label>
<input type="password" name="password" required>

<label>Confirm Password:</label>
<input type="password" name="confirm_password" required>

<button type="submit">Register</button>
<p>Already have an account? <a href="login.php">Login</a></p>
</form>
</div>
</body>

</html>
