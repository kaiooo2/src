<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Annai Agency Sewing Machine</title>
<link rel="stylesheet" href="assets/css/header.css">
</head>
<body>
<div class="top-bar">
<div class="logo">
</div>
<div class="name1">
    <h3>Annai Agency Sewing Machine</h3>
</div>
<div class="nav-links">
<ul class="nav-links">
<li><a href="./home.php">Home</a></li>
<li><a href="./about.php">About</a></li>
<li class="dropdown">
<a href="#">Categories ▼</a>
<ul class="dropdown-menu">
<li><a href="./jack_machine.php">Jack Machine</a></li>
<li><a href="./juki_machine.php">Juki Machine</a></li>
<li><a href="./zoje_machine.php">Zoje Machine</a></li>
<li><a href="./revo_machine.php">Revo Machine</a></li>
<li><a href="./meerit_machine.php">Meerit Machine</a></li>
<li><a href="./singer_machine.php">Singer Machine</a></li>
</ul>
</li>
<li><a href="./product.php">Products</a></li>
<li><a href="./orders.php">Orders</a></li>

<?php if(isset($_SESSION['username'])): ?>
<li><a href="./logout.php">Logout</a></li>
<?php else: ?>
<li><a href="./login.php">Login</a></li>
<?php endif; ?>
</ul>

</div>
<div class="searchbox">
<form action="./search.php" method="GET">
<input type="text" name="query" placeholder="Search Machines...">
<button type="submit">Search</button>
</form>
</div>
</div>
</div>
</div>
</body>
</html>