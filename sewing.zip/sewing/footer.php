<!DOCTYPE html>
<html lang=”en”>

<head>
<meta charset=”UTF-8”>
<title>Footer Fix</title>
<style>
        html, body {
            margin: 0;
            padding: 0;
            Height: 100%;
            overflow-x:hidden;
        }
        .wrapper {
            display: flex;
            flex-direction: column;
           
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .footer-bottom {
            background: #333;
            color: white;
            width: 100%;
            Height:50px;
            text-align: center;
            padding: 10px 0;
        }
</style>
</head>

<body>
<div class="wrapper">
<div class="footer-bottom">
<p>&copy; 2025 Annai Agency Sewing Machine | All Rights Reserved</p>
</div>

</div>
</body>

</html>
