<?php
session_start();
$database_name = "product_details";
$con = mysqli_connect("localhost", "root", "", $database_name);
if (!isset($_SESSION["cart"]) || !is_array($_SESSION["cart"])) {
    $_SESSION["cart"] = array();
}
if (isset($_POST["add"])) {
    $product_id = $_GET["id"];
    $item_quantity = (int)$_POST["quantity"];
    $found = false;
foreach ($_SESSION["cart"] as $key => $item) {
        if ($item["product_id"] == $product_id) {
            $_SESSION["cart"][$key]["item_quantity"] += $item_quantity;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $item_array =array (
            "product_id" => $product_id,
            "item_name" => $_POST["hidden_name"],
            "product_price" => $_POST["hidden_price"],
            "item_quantity" => $item_quantity,
        );
        $_SESSION["cart"][$product_id] = $item_array; 
        echo '<script>alert("Product added")</script>';
    }else{
        echo '<script>alert("Product is update in the cart")</script>';
        echo '<script>window.location="product.php"</script>';
    }
}
if (isset($_GET["action"]) && $_GET["action"] == "delete") {
    if (!empty($_SESSION["cart"])) {
foreach ($_SESSION["cart"] as $key => $value) {
            if ($value["product_id"] == $_GET["id"]) {
                unset($_SESSION["cart"][$key]);
                $_SESSION["cart"] = array_values($_SESSION["cart"]);
                echo '<script>alert("Product has been removed!")</script>';
                echo '<script>window.location="orders.php"</script>';
                break;
            }
        }
    }
}
?>
