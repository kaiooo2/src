<?php
session_start();
if (!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = [];
}

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $name = "Product Name";  // Fetch from database
    $price = 100;            // Fetch from database

    if (isset($_SESSION["cart"][$id])) {
        $_SESSION["cart"][$id]["quantity"] += 1;
    } else {
        $_SESSION["cart"][$id] = [
            "name" => $name,
            "price" => $price,
            "quantity" => 1
        ];
    }
}
header("Location: orders.php");
exit();
?>