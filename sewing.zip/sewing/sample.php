<?php 
include 'header.php';
include 'config.php';

$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;
$category_name = "";

// Fetch category name
if ($category_id) {
    $category_qry = $conn->query("SELECT name FROM category_list WHERE category_id = $category_id");
    if ($category_qry->num_rows > 0) {
        $category_row = $category_qry->fetch_assoc();
        $category_name = $category_row['name'];
    }
}

// Fetch products
$sql = "SELECT p.*, c.name AS category_name 
        FROM product_list p 
        INNER JOIN category_list c ON p.category_id = c.category_id 
        WHERE p.delete_flag = 0 
        ORDER BY p.name ASC";

if ($category_id) {
    $sql = "SELECT p.*, c.name AS category_name 
            FROM product_list p 
            INNER JOIN category_list c ON p.category_id = c.category_id 
            WHERE p.category_id = $category_id AND p.delete_flag = 0 
            ORDER BY p.name ASC";
}

$qry = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Products</title>
<link rel="stylesheet" href="./assets/css/product.css">
</head>
<body>

<h2>Our Products</h2>

<?php if ($category_name): ?>
<h3>Category: <?php echo $category_name; ?></h3>
<?php endif; ?>

<div class="product-grid">
<?php while ($row = $qry->fetch_assoc()): ?>
<div class="product">
<img src="data:image/jpeg;base64,<?php echo base64_encode($row['product_image']); ?>" alt="<?php echo $row['name']; ?>">
<h5><?php echo $row['name']; ?></h5>
<p><?php echo $row['description']; ?></p>
<p class="price">₹<?php echo number_format($row['price'], 2); ?></p>
<p class="stock">Stock: <?php echo $row['alert_restock'] > 0 ? $row['alert_restock'] : '<span class="out-of-stock">Out of Stock</span>'; ?></p>
<?php if ($row['alert_restock'] > 0): ?>
<form method="post" action="cart.php?action=add&id=<?php echo $row['product_id']; ?>">
<input type="hidden" name="hidden_name" value="<?php echo $row['name']; ?>">
<input type="hidden" name="hidden_price" value="<?php echo $row['price']; ?>">
<input type="number" name="quantity" value="1" min="1" max="<?php echo $row['alert_restock']; ?>">
<button type="submit" name="add" class="btn">Add to Cart</button>
</form>
<?php else: ?>
<button class="btn disabled" disabled>Out of Stock</button>
<?php endif; ?>
</div>
<?php endwhile; ?>
</div>
    <?php
    include 'footer.php';
    ?>
</body>
</html>
