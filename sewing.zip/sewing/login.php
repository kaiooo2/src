<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (md5($password, $user['password'])) {
            $_SESSION['username'] = $user['username'];
            header("Location: home.php");
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>Login | Annai Agency</title>
<link rel="stylesheet" href="./assets/css/login.css">
</head>

<body>
<div class="container">
<h2>Login</h2>
<?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
<form method="POST" action="">
<label>Username:</label>
<input type="text" name="username" required>

<label>Password:</label>
<input type="password" name="password" required>

<button type="submit">Login</button>
<p>Don't have an account? <a href="register.php">Register</a></p>
</form>
</div>
</body>

</html>
