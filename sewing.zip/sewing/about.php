<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>About Us – Annai Agency Sewing Machine</title>
<link rel="stylesheet" href="./assets/css/about.css">

</head>
<body>
    <div class="about">
        <div class="content1">
        <h1>About Annai Agency Sewing Machine</h1>
        </div>
        <div class="content2">
        <p>
        Welcome to <strong>Annai Agency</strong>, your trusted destination for high-quality sewing machines. 
        We specialize in providing a wide range of industrial and domestic sewing machines, including 
        Popular brands like Jack, Juki, Zoje, Revo, Singer, and Meerit Machines.
        </p>
        </div>
        <div class="content3">
        <p>
        Our mission is to deliver top-notch products and exceptional service to our valued customers. 
        With years of expertise in the sewing industry, we understand the importance of reliability 
        And precision. We aim to provide our customers with the best solutions tailored to their needs.
        </p>
        </div>
        <div class="content4">
            
<p>
        Our online platform allows you to browse our collection, place orders with ease, and have your 
        Sewing machines delivered right to your doorstep. At Annai Agency, we pride ourselves on maintaining 
        Transparency, offering competitive prices, and ensuring complete customer satisfaction.
</p>
        </div>
        <div class="content5">
<h3>Contact Us</h3><br><br>
<p><strong>Address:</strong> Office Rd, Virudhunagar, Tamil Nadu 626001</p><br>
<p><strong>Phone:</strong> +91-77085 35479</p><br>
<p><strong>Email:</strong> info@annaisewingmachine.com</p>
</div>
        </div>
    </div>
</body>
<?php
include 'footer.php';
?>
</html>