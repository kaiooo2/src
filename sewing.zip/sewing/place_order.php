<?php
session_start();
include 'config.php';
$user_email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $order_date = date("Y-m-d H:i:s");
    if (!empty($_SESSION["orders"])) {
foreach ($_SESSION["orders"] as $order) {
            $product_name = $order["product_name"];
            $quantity = $order["quantity"];
            $price = $order["product_price"];
            $total_price = $quantity * $price;
            $sql = "INSERT INTO orders (name, address, phone, email, product_name, quantity, price, total_price, order_date) 
                    VALUES ('$name', '$address', '$phone', '$email', '$product_name', $quantity, $price, $total_price, '$order_date')";
mysqli_query($conn, $sql);
        }
        unset($_SESSION["orders"]);

        echo "<script>alert('Order placed successfully!'); window.location.href='orders.php';</script>";
    } else {
        echo "<script>alert('No products in the cart!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Place Your Order</title>
<style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
th {
            background-color: #00aaed;
color: white;
        }
        .btn {
            background-color: #28a745;
color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
        }
</style>
</head>
<body>

<h2>Place Your Order</h2>
<form method="POST" action="">
<label>Name:</label>
<input type="text" name="name" required><br><br>

<label>Address:</label>
<textarea name="address" required></textarea><br><br>

<label>Phone No:</label>
<input type="text" name="phone" required><br><br>

<label>Email:</label>
<input type="email" name="email" value="<?php echo $user_email; ?>" required><br><br>

<h3>Order Summary</h3>
<table>
<tr>
<th>Product Name</th>
<th>Quantity</th>
<th>Price</th>
<th>Total</th>
</tr>
<?php
        if (!empty($_SESSION["orders"])) {
foreach ($_SESSION["orders"] as $order) {
                echo "<tr>
<td>{$order['product_name']}</td>
<td>{$order['quantity']}</td>
<td>₹" . number_format($order['product_price'], 2) . "</td>
<td>₹" . number_format($order['quantity'] * $order['product_price'], 2) . "</td>
</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No products in the cart.</td></tr>";
        }
        ?>
</table>

<br>
<button type="submit" class="btn">Confirm Order</button>
</form>

</body>
</html>
