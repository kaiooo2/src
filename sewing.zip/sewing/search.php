<?php
include 'config.php';
session_start();

$search = isset($_GET['query']) ? mysqli_real_escape_string($conn, $_GET['query']) : "";
$query = "SELECT p.*, c.name AS category_name 
          FROM product_list p 
          INNER JOIN category_list c ON p.category_id = c.category_id 
          WHERE p.name LIKE '$search%'
          UNION 
          SELECT p.*, c.name AS category_name 
          FROM product_list p 
          INNER JOIN category_list c ON p.category_id = c.category_id 
          WHERE p.name LIKE '%$search%' AND p.name NOT LIKE '$search%' 
          ORDER BY name ASC";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Search Results</title>
<style>
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .product-table th, .product-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .product-table th {
            background-color: #00aaed;
            color: white;
        }
        .product-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }
        .out-of-stock {
            color: red;
            font-weight: bold;
        }
        .add-to-cart {
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 3px;
        }
        .add-to-cart.disabled {
            background-color: gray;
            pointer-events: none;
        }
</style>
</head>
<body>

<h2>Search Results for "<?php echo htmlspecialchars($search); ?>"</h2>

<table class="product-table">
<thead>
<tr>
<th>S.No</th>
<th>Category</th>
<th>Product</th>
<th>Description</th>
<th>Image</th>
<th>Price</th>
<th>Stock</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php 
        $i = 1;
        while ($row = mysqli_fetch_assoc($result)): 
            $stock = $row['alert_restock'];
        ?>
<tr>
<td><?php echo $i++; ?></td>
<td><?php echo htmlspecialchars($row['category_name']); ?></td>
<td><?php echo htmlspecialchars($row['name']); ?></td>
<td><?php echo htmlspecialchars($row['description']); ?></td>
<td>
<?php if (!empty($row['product_image'])): ?>
<img src="data:image/jpeg;base64,<?php echo base64_encode($row['product_image']); ?>" class="product-img">
<?php else: ?>
<img src="assets/img/no-image-available.png" class="product-img">
<?php endif; ?>
</td>
<td>₹<?php echo number_format($row['price'], 2); ?></td>
<td><?php echo $stock > 0 ? $stock : '<span class="out-of-stock">Out of Stock</span>'; ?></td>
<td>
<?php if ($stock > 0): ?>
<a href="product.php?action=add&id=<?php echo $row['product_id']; ?>&name=<?php echo urlencode($row['name']); ?>&price=<?php echo $row['price']; ?>" class="add-to-cart">Add to Cart</a>
<?php else: ?>
<span class="add-to-cart disabled">Out of Stock</span>
<?php endif; ?>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
    <a href="./product.php">Continue Shopping</a>
</body>
</html>

<?php
mysqli_close($conn);
?>
