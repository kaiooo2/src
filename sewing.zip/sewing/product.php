<?php 
include 'config.php';
include 'header.php';

$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;
$category_name = "";
if ($category_id) {
    $category_qry = $conn->query("SELECT name FROM category_list WHERE category_id = $category_id");
    if ($category_qry->num_rows > 0) {
        $category_row = $category_qry->fetch_assoc();
        $category_name = $category_row['name'];
    }
}
$sql = "SELECT p.*, c.name AS category_name 
        FROM product_list p 
        INNER JOIN category_list c ON p.category_id = c.category_id 
        WHERE p.delete_flag = 0 
        ORDER BY p.name ASC";

if ($category_id) {
    $sql = "SELECT p.*, c.name AS category_name 
            FROM product_list p 
            INNER JOIN category_list c ON p.category_id = c.category_id 
            WHERE p.category_id = $category_id AND p.delete_flag = 0 
            ORDER BY p.name ASC";
}

$qry = $conn->query($sql);
if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $product_name = $_GET['name'];
    $product_price = $_GET['price'];
    $stock_qry = $conn->query("SELECT alert_restock FROM product_list WHERE product_id = $product_id");
    $stock_data = $stock_qry->fetch_assoc();
    $current_stock = $stock_data['alert_restock'];

    if ($current_stock > 0) {
        if (!isset($_SESSION["orders"])) {
            $_SESSION["orders"] = [];
        }

        $found = false;
        foreach ($_SESSION["orders"] as $key => $item) {
            if ($item["product_id"] == $product_id) {
                if ($item["quantity"] < $current_stock) {
                    $_SESSION["orders"][$key]["quantity"] += 1;
                    $found = true;
                }
                break;
            }
        }

        if (!$found) {
            $_SESSION["orders"][] = [
                "product_id" => $product_id,
                "product_name" => $product_name,
                "product_price" => $product_price,
                "quantity" => 1
            ];
        }
        $new_stock = $current_stock - 1;
        $conn->query("UPDATE product_list SET alert_restock = $new_stock WHERE product_id = $product_id");

        header("Location: orders.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Products</title>
<style>
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .product-table th, .product-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .product-table th {
            background-color: #00aaed;
            color: white;
        }
        .product-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }
        .out-of-stock {
            color: red;
            font-weight: bold;
        }
        .add-to-cart {
            background-color: #28a745;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 3px;
        }
        .add-to-cart.disabled {
            background-color: gray;
            pointer-events: none;
        }
</style>
</head>
<body>

<h2>Our Products</h2>

<?php if ($category_name): ?>
<h3>Category: <?php echo $category_name; ?></h3>
<?php endif; ?>

<table class="product-table">
<thead>
<tr>
<th>S.No</th>
<th>Category</th>
<th>Product</th>
<th>Description</th>
<th>Image</th>
<th>Price</th>
<th>Stock</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php 
        $i = 1;
        while ($row = $qry->fetch_assoc()): 
            $stock = $row['alert_restock'];
        ?>
<tr>
<td><?php echo $i++; ?></td>
<td><?php echo $row['category_name']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['description']; ?></td>
<td>
<?php if (!empty($row['product_image'])): ?>
<img src="data:image/jpeg;base64,<?php echo base64_encode($row['product_image']); ?>" class="product-img">
<?php else: ?>
<img src="assets/img/no-image-available.png" class="product-img">
<?php endif; ?>
</td>
<td>₹<?php echo number_format($row['price'], 2); ?></td>
<td><?php echo $stock > 0 ? $stock : '<span class="out-of-stock">Out of Stock</span>'; ?></td>
<td>
<?php if ($stock > 0): ?>
<a href="product.php?action=add&id=<?php echo $row['product_id']; ?>&name=<?php echo urlencode($row['name']); ?>&price=<?php echo $row['price']; ?>" class="add-to-cart">Add to Cart</a>
<?php else: ?>
<span class="add-to-cart disabled">Out of Stock</span>
<?php endif; ?>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

</body>
</html>
