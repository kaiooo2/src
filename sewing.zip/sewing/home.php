<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sewing Machine</title>
    <link rel="stylesheet" href="./assets/css/header.css">
    <link rel="stylesheet" href="./assets/css/home.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
<div class="slider">
<figure>
<div class="slide">
<h1>GambarSatu</h1>
<img src="assets/img/1.jpg" alt="">
</div>
<div class="slide">
<h1>GambarDua</h1>
<img src="assets/img/2.png" alt="">
</div>
<div class="slide">
<h1>GambarTiga</h1>
<img src="assets/img/3.png" alt="">
</div>
<div class="slide">
<h1>GambarEmpat</h1>
<img src="assets/img/4.jpg" alt="">
</div>
</figure>
</div>



    <div class="container">
         <img src="./assets/img/2.png" alt="">
    </div>
    <div class="name">
        <h3>Annai Agency</h3>
    </div>
    <div class="container11">
<div class="container2">
<h1>Explore Machines</h1>
<div class="boxes">

<a href="jack-machine.html">
<div class="box-3">
<img src="./assets/img/1.jpg" alt="Jack Machine" class="img-responsive">
<h3 class="float-text">Jack Machine</h3>
</div>
</a>

<a href="juki-machine.html">
<div class="box-3">
<img src="./assets/img/2.png" alt="Juki Machine" class="img-responsive">
<h3 class="float-text">Juki Machine</h3>
</div>
</a>

<a href="zoje-machine.html">
<div class="box-3">
<img src="./assets/img/3.png" alt="Zoje Machine" class="img-responsive">
<h3 class="float-text">Zoje Machine</h3>
</div>
</a>
</div>
<div class="boxes1">
<a href="revo-machine.html">
<div class="box-3">
<img src="./assets/img/1.jpg" alt="Revo Machine" class="img-responsive">
<h3 class="float-text">Revo Machine</h3>
</div>
</a>

<a href="singer-machine.html">
<div class="box-3">
<img src="./assets/img/2.png" alt="Singer Machine" class="img-responsive">
<h3 class="float-text">Singer Machine</h3>
</div>
</a>

<a href="singer-machine.html">
<div class="box-3">
<img src="./assets/img/2.png" alt="Singer Machine" class="img-responsive">
<h3 class="float-text">Singer Machine</h3>
</div>
</a>

</div>
</div>
</div>
</body>
<?php
include 'footer.php';
?>
</html>