<?php
include 'config.php';
include 'header.php';
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['key'])) {
    $key = $_GET['key'];

    if (isset($_SESSION["orders"][$key])) {
        $product_id = $_SESSION["orders"][$key]["product_id"];
        $quantity_to_restore = $_SESSION["orders"][$key]["quantity"];
        $conn->query("UPDATE product_list SET alert_restock = alert_restock + $quantity_to_restore WHERE product_id = $product_id");
        unset($_SESSION["orders"][$key]);
    }
    header("Location: orders.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Order Details</title>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: center;
    }
    th {
        background-color: #00aaed;
        color: white;
    }
    .btn {
        background-color: #28a745;
        color: white;
        padding: 5px 10px;
        text-decoration: none;
        border-top:30px;
        border-radius: 3px;
        text-align:center;
    }
    .btn-remove {
        background-color: red;
        color: white;
        padding: 5px 10px;
        text-decoration: none;
        border-radius: 3px;
    }
</style>
</head>
<body>

<h2>Order Details</h2>
<table>
<tr>
<th>Product Name</th>
<th>Quantity</th>
<th>Price</th>
<th>Total Price</th>
<th>Remove</th>
</tr>

<?php
    if (!empty($_SESSION["orders"])) {
        $total = 0;
        foreach ($_SESSION["orders"] as $key => $value) {
            ?>
<tr>
<td><?php echo $value["product_name"]; ?></td>
<td><?php echo $value["quantity"]; ?></td>
<td>₹<?php echo number_format($value["product_price"], 2); ?></td>
<td>₹<?php echo number_format($value["quantity"] * $value["product_price"], 2); ?></td>
<td><a href="orders.php?action=remove&key=<?php echo $key; ?>" class="btn-remove">Remove</a></td>
</tr>
<?php
            $total += $value["quantity"] * $value["product_price"];
        }
        ?>
<tr>
<td colspan="3" align="right"><strong>Total:</strong></td>
<td><strong>₹<?php echo number_format($total, 2); ?></strong></td>
<td></td>
</tr>
<?php } else { ?>
<tr>
<td colspan="5">No products in the cart.</td>
</tr>
<?php } ?>
</table>

<div>
<a href="place_order.php" class="btn">Place Order</a>
</div>

</body>
</html>
