<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $utr_number = trim($_POST['utr_number']);

    if (!empty($utr_number)) {
        $booking = $_SESSION['booking'];
        $slot_id = $booking['slot_id'];

        // First, check if 'utr_number' column exists in 'parking_slots'
        $result = $conn->query("SHOW COLUMNS FROM parking_slots LIKE 'utr_number'");
        if ($result->num_rows == 0) {
            die("Error: 'utr_number' column is missing in parking_slots table.");
        }

        // Update parking slot status and store UTR number
        $query = "UPDATE parking_slots SET status='occupied', utr_number='$utr_number' WHERE id='$slot_id'";
        if ($conn->query($query)) {
            unset($_SESSION['booking']); // Clear session
            header("Location: home.php"); // Redirect after successful payment
            exit();
        } else {
            echo "Database error: " . $conn->error;
        }
    } else {
        echo "Invalid UTR number. Please try again.";
    }
}
?>
