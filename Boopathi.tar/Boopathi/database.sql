CREATE DATABASE parking_system;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE parking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slot_number VARCHAR(10) NOT NULL UNIQUE,
    status ENUM('available', 'occupied') NOT NULL DEFAULT 'available'
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_email VARCHAR(100) NOT NULL,
    slot_id INT NOT NULL,
    car_number VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    license_number VARCHAR(30) NOT NULL,
    government_id VARCHAR(255) NOT NULL,
    status ENUM('pending', 'confirmed', 'rejected') DEFAULT 'pending',
    FOREIGN KEY (user_email) REFERENCES users(email),
    FOREIGN KEY (slot_id) REFERENCES parking_slots(id)
);
------------------------------
ALTER TABLE parking_slots ADD COLUMN location VARCHAR(255) NOT NULL;
DESCRIBE parking_slots;

INSERT INTO parking_slots (slot_number, status, location) VALUES
-- Bus Stand Parking (25 slots)
(1, 'available', 'Bus Stand'), (2, 'available', 'Bus Stand'), (3, 'available', 'Bus Stand'),
(4, 'available', 'Bus Stand'), (5, 'available', 'Bus Stand'),
(6, 'available', 'Bus Stand'), (7, 'available', 'Bus Stand'), (8, 'available', 'Bus Stand'),
(9, 'available', 'Bus Stand'), (10, 'available', 'Bus Stand'),
(11, 'available', 'Bus Stand'), (12, 'available', 'Bus Stand'), (13, 'available', 'Bus Stand'),
(14, 'available', 'Bus Stand'), (15, 'available', 'Bus Stand'),
(16, 'available', 'Bus Stand'), (17, 'available', 'Bus Stand'), (18, 'available', 'Bus Stand'),
(19, 'available', 'Bus Stand'), (20, 'available', 'Bus Stand'),
(21, 'available', 'Bus Stand'), (22, 'available', 'Bus Stand'), (23, 'available', 'Bus Stand'),
(24, 'available', 'Bus Stand'), (25, 'available', 'Bus Stand'),

-- School Opposite Parking (25 slots)
(26, 'available', 'School Opposite'), (27, 'available', 'School Opposite'), (28, 'available', 'School Opposite'),
(29, 'available', 'School Opposite'), (30, 'available', 'School Opposite'),
(31, 'available', 'School Opposite'), (32, 'available', 'School Opposite'), (33, 'available', 'School Opposite'),
(34, 'available', 'School Opposite'), (35, 'available', 'School Opposite'),
(36, 'available', 'School Opposite'), (37, 'available', 'School Opposite'), (38, 'available', 'School Opposite'),
(39, 'available', 'School Opposite'), (40, 'available', 'School Opposite'),
(41, 'available', 'School Opposite'), (42, 'available', 'School Opposite'), (43, 'available', 'School Opposite'),
(44, 'available', 'School Opposite'), (45, 'available', 'School Opposite'),
(46, 'available', 'School Opposite'), (47, 'available', 'School Opposite'), (48, 'available', 'School Opposite'),
(49, 'available', 'School Opposite'), (50, 'available', 'School Opposite'),

-- College Opposite Parking (25 slots)
(51, 'available', 'College Opposite'), (52, 'available', 'College Opposite'), (53, 'available', 'College Opposite'),
(54, 'available', 'College Opposite'), (55, 'available', 'College Opposite'),
(56, 'available', 'College Opposite'), (57, 'available', 'College Opposite'), (58, 'available', 'College Opposite'),
(59, 'available', 'College Opposite'), (60, 'available', 'College Opposite'),
(61, 'available', 'College Opposite'), (62, 'available', 'College Opposite'), (63, 'available', 'College Opposite'),
(64, 'available', 'College Opposite'), (65, 'available', 'College Opposite'),
(66, 'available', 'College Opposite'), (67, 'available', 'College Opposite'), (68, 'available', 'College Opposite'),
(69, 'available', 'College Opposite'), (70, 'available', 'College Opposite'),
(71, 'available', 'College Opposite'), (72, 'available', 'College Opposite'), (73, 'available', 'College Opposite'),
(74, 'available', 'College Opposite'), (75, 'available', 'College Opposite'),

-- Main Road Parking (25 slots)
(76, 'available', 'Main Road'), (77, 'available', 'Main Road'), (78, 'available', 'Main Road'),
(79, 'available', 'Main Road'), (80, 'available', 'Main Road'),
(81, 'available', 'Main Road'), (82, 'available', 'Main Road'), (83, 'available', 'Main Road'),
(84, 'available', 'Main Road'), (85, 'available', 'Main Road'),
(86, 'available', 'Main Road'), (87, 'available', 'Main Road'), (88, 'available', 'Main Road'),
(89, 'available', 'Main Road'), (90, 'available', 'Main Road'),
(91, 'available', 'Main Road'), (92, 'available', 'Main Road'), (93, 'available', 'Main Road'),
(94, 'available', 'Main Road'), (95, 'available', 'Main Road'),
(96, 'available', 'Main Road'), (97, 'available', 'Main Road'), (98, 'available', 'Main Road'),
(99, 'available', 'Main Road'), (100, 'available', 'Main Road');
-----------------------------------------
CREATE DATABASE IF NOT EXISTS parking_system;
USE parking_system;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Parking Slots Table
CREATE TABLE IF NOT EXISTS parking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slot_number INT UNIQUE NOT NULL,
    location VARCHAR(255) NOT NULL,
    status ENUM('available', 'occupied') DEFAULT 'available'
);

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_email VARCHAR(255) NOT NULL,
    slot_id INT NOT NULL,
    car_number VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
    license_number VARCHAR(50) NOT NULL,
    aadhaar_number VARCHAR(20) NOT NULL,
    days INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'confirmed') DEFAULT 'pending',
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (slot_id) REFERENCES parking_slots(id),
    FOREIGN KEY (user_email) REFERENCES users(email) ON DELETE CASCADE
);


CREATE TABLE parking_slots (
    id INT PRIMARY KEY AUTO_INCREMENT,
    location VARCHAR(255),
    slot_number INT,
    status ENUM('available', 'occupied') DEFAULT 'available'
);


CREATE TABLE upi_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    upi_id VARCHAR(255) NOT NULL,
    receiver_name VARCHAR(255) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO upi_details (upi_id, receiver_name) 
VALUES ('boopathi3072005@okaxis', 'Boopathi');


ALTER TABLE parking_slots ADD COLUMN utr_number VARCHAR(50) NULL;

$query = "INSERT INTO payments (slot_id, utr_number, amount) VALUES ('$slot_id', '$utr_number', '{$booking['amount']}')";
---------------------------------------------------------------------------------------------------------------

ALTER TABLE bookings ADD COLUMN user_id INT NOT NULL AFTER id;
ALTER TABLE bookings ADD FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;
    ALTER TABLE users ADD COLUMN phone VARCHAR(20);
    --------------------------------------------
-- Create users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    car_number VARCHAR(20) NOT NULL,
    license_number VARCHAR(50) NOT NULL,
    aadhaar_number VARCHAR(20) NOT NULL
);

-- Create parking slots table
CREATE TABLE parking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    status ENUM('available', 'occupied') DEFAULT 'available'
);

-- Create bookings table
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    slot_id INT,
    days INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('pending', 'paid') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES parking_slots(id) ON DELETE CASCADE
);
