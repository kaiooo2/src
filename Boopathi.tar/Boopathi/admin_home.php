<?php
session_start();
include 'config.php'; // Include database connection

// Fetch total slots count
$total_slots_query = $conn->query("SELECT COUNT(*) AS total FROM parking_slots");
$total_slots = $total_slots_query->fetch_assoc()['total'];

// Fetch occupied slots count
$occupied_slots_query = $conn->query("SELECT COUNT(*) AS occupied FROM parking_slots WHERE status='occupied'");
$occupied_slots = $occupied_slots_query->fetch_assoc()['occupied'];

// Fetch available slots count
$available_slots = $total_slots - $occupied_slots;

// Fetch booking details
$bookings_query = $conn->query("SELECT * FROM bookings ORDER BY id DESC");

// Admin unbooks a slot (makes it available)
if (isset($_GET['unbook'])) {
    $id = $_GET['unbook'];
    
    // Get the slot ID of the booking
    $slot_query = $conn->query("SELECT slot_id FROM bookings WHERE id = $id");
    $slot = $slot_query->fetch_assoc()['slot_id'];

    // Remove the booking and set the slot as available
    $conn->query("DELETE FROM bookings WHERE id = $id");
    $conn->query("UPDATE parking_slots SET status='available' WHERE id='$slot'");

    // Refresh page
    header("Location: admin_home.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="Css/adminhome.css">
</head>
<body>

<header>
    <h2>Admin Dashboard</h2>
    <a href="logout.php">Logout</a>
</header>

<div class="dashboard-container">

    <div class="stats">
        <div class="card total">
            <h3>Total Slots</h3>
            <p><?php echo $total_slots; ?></p>
        </div>
        <div class="card occupied">
            <h3>Occupied Slots</h3>
            <p><?php echo $occupied_slots; ?></p>
        </div>
        <div class="card available">
            <h3>Available Slots</h3>
            <p><?php echo $available_slots; ?></p>
        </div>
    </div>

    <h3>Recent Bookings</h3>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Slot</th>
                <th>Days</th>
                <th>Amount</th>
                <th>Payment</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $bookings_query->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo "Slot " . $row['slot_id']; ?></td>
                    <td><?php echo $row['days']; ?></td>
                    <td>₹<?php echo $row['amount']; ?></td>
                    <td><?php echo ($row['payment_status'] == 'paid') ? "<span class='paid'>Paid</span>" : "<span class='pending'>Pending</span>"; ?></td>
                    <td>
                        <?php if ($row['payment_status'] == 'pending'): ?>
                            <a href="verify_payment.php?id=<?php echo $row['id']; ?>" class="btn verify">Verify</a>
                        <?php else: ?>
                            <span class="verified">Verified</span>
                        <?php endif; ?>
                        
                        <?php
                        // Check if the slot is occupied before showing the "Unbook" button
                        $slot_check = $conn->query("SELECT status FROM parking_slots WHERE id = '{$row['slot_id']}'");
                        $slot_status = $slot_check->fetch_assoc()['status'];
                        
                        if ($slot_status == 'occupied'): ?>
                            <a href="admin_home.php?unbook=<?php echo $row['id']; ?>" class="btn unbook" 
                               onclick="return confirm('Are you sure you want to unbook this slot?')">Unbook</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

</body>
</html>