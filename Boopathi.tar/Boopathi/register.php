<?php
session_start();
include 'db_connect.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_BCRYPT);

    // Check if email already exists
    $check_query = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error = "Email already exists!";
    } else {
        // Check if 'name' column exists in the database
        $table_check = "SHOW COLUMNS FROM users LIKE 'name'";
        $column_result = $conn->query($table_check);

        if ($column_result->num_rows == 0) {
            // If 'name' column is missing, use 'full_name' instead
            $query = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";
        } else {
            $query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        }

        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            $_SESSION["user"] = $email;
            header("Location: home.php"); // Redirect to home page
            exit();
        } else {
            $error = "Registration failed! Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="css/user.css"> <!-- Fixed CSS path -->
</head>
<body>
    <div class="register-container">
        <h2>Register</h2>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <form action="" method="POST">
            <label for="name">Full Name:</label>
            <input type="text" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" name="email" required>
            
            <label for="password">Password:</label>
            <input type="password" name="password" required>
            
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <button onclick="location.href='login.php'">Login</button></p>
    </div>
</body>
</html>
