<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

// Fetch all parking slots grouped by location
$query = "SELECT * FROM parking_slots ORDER BY location, slot_number";
$result = $conn->query($query);

// Categorize slots by location
$parking_slots = [];
while ($row = $result->fetch_assoc()) {
    $parking_slots[$row['location']][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Slots - Sivakasi</title>
    <link rel="stylesheet" href="Css/parking.css">
</head>
<body>
    <header>
        <h2>Parking Slots in Sivakasi</h2>
        
        <a href="logout.php">Logout</a>
    </header>

    <div class="parking-container">
        <h3>    </h3>
        <?php foreach ($parking_slots as $location => $slots): ?>
            <h3><?php echo $location; ?> Parking</h3>
            <div class="slot-container">
                <?php foreach ($slots as $slot): ?>
                    <div class="slot <?php echo $slot['status'] == 'occupied' ? 'occupied' : 'available'; ?>">
                        <p>Slot <?php echo $slot['slot_number']; ?></p>
                        <p>Status: <?php echo ucfirst($slot['status']); ?></p>
                        <?php if ($slot['status'] == 'available'): ?>
                            <a href="booking_details.php?slot_id=<?php echo $slot['id']; ?>">
                                <button class="book-btn">Book Now</button>
                            </a>
                        <?php else: ?>
                            <button disabled>Booked</button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
