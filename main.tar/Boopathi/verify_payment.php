<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $utr_number = trim($_POST['utr_number']);
    $slot_id = intval($_POST['slot_id']);
    $booking_id = intval($_POST['booking_id']);

    if (!empty($utr_number) && $slot_id > 0 && $booking_id > 0) {
        $stmt = $conn->prepare("UPDATE parking_slots SET status='occupied', utr_number=? WHERE id=?");
        $stmt->bind_param("si", $utr_number, $slot_id);

        if ($stmt->execute()) {
            $stmt2 = $conn->prepare("UPDATE bookings SET payment_status='paid' WHERE id=?");
            $stmt2->bind_param("i", $booking_id);
            $stmt2->execute();

            unset($_SESSION['booking_id']);
            // Redirect to success page with booking ID
            header("Location: payment_success.php?booking_id=" . $booking_id);
            exit();
        } else {
            echo "Database error: " . $stmt->error;
        }
    } else {
        echo "Invalid UTR, Slot ID or Booking ID.";
    }
}
?>
<?php
// verify_payment.php
include 'config.php';
session_start();

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
    // Mark payment as verified (paid)
    $conn->query("UPDATE bookings SET payment_status = 'paid' WHERE id = $booking_id");
}

header("Location: admin_home.php");
exit();
?>
