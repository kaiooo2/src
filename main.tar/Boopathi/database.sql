---------------------------RE-work-----------
CREATE DATABASE IF NOT EXISTS parking_system;
USE parking_system;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

------------------------------------------------------------------
CREATE TABLE parking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(255) NOT NULL,
    slot_number INT NOT NULL,
    status ENUM('available', 'occupied') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE parking_slots ADD COLUMN utr_number VARCHAR(50) NULL;
ALTER TABLE parking_slots ADD COLUMN location_name VARCHAR(255);

-- Sivakasi Bus Stand Parking
INSERT INTO parking_slots (location, slot_number, status) VALUES
('Sivakasi Bus Stand Parking', 1, 'available'),
('Sivakasi Bus Stand Parking', 2, 'available'),
('Sivakasi Bus Stand Parking', 3, 'available'),
('Sivakasi Bus Stand Parking', 4, 'available'),
('Sivakasi Bus Stand Parking', 5, 'available'),
('Sivakasi Bus Stand Parking', 6, 'available'),
('Sivakasi Bus Stand Parking', 7, 'available'),
('Sivakasi Bus Stand Parking', 8, 'available'),
('Sivakasi Bus Stand Parking', 9, 'available'),
('Sivakasi Bus Stand Parking', 10, 'available'),
('Sivakasi Bus Stand Parking', 11, 'available'),
('Sivakasi Bus Stand Parking', 12, 'available'),
('Sivakasi Bus Stand Parking', 13, 'available'),
('Sivakasi Bus Stand Parking', 14, 'available'),
('Sivakasi Bus Stand Parking', 15, 'available'),
('Sivakasi Bus Stand Parking', 16, 'available'),
('Sivakasi Bus Stand Parking', 17, 'available'),
('Sivakasi Bus Stand Parking', 18, 'available'),
('Sivakasi Bus Stand Parking', 19, 'available'),
('Sivakasi Bus Stand Parking', 20, 'available'),
('Sivakasi Bus Stand Parking', 21, 'available'),
('Sivakasi Bus Stand Parking', 22, 'available'),
('Sivakasi Bus Stand Parking', 23, 'available'),
('Sivakasi Bus Stand Parking', 24, 'available'),
('Sivakasi Bus Stand Parking', 25, 'available');

-- Virudhunagar Bus Stand Parking
INSERT INTO parking_slots (location, slot_number, status) VALUES
('Virudhunagar Bus Stand Parking', 1, 'available'),
('Virudhunagar Bus Stand Parking', 2, 'available'),
('Virudhunagar Bus Stand Parking', 3, 'available'),
('Virudhunagar Bus Stand Parking', 4, 'available'),
('Virudhunagar Bus Stand Parking', 5, 'available'),
('Virudhunagar Bus Stand Parking', 6, 'available'),
('Virudhunagar Bus Stand Parking', 7, 'available'),
('Virudhunagar Bus Stand Parking', 8, 'available'),
('Virudhunagar Bus Stand Parking', 9, 'available'),
('Virudhunagar Bus Stand Parking', 10, 'available'),
('Virudhunagar Bus Stand Parking', 11, 'available'),
('Virudhunagar Bus Stand Parking', 12, 'available'),
('Virudhunagar Bus Stand Parking', 13, 'available'),
('Virudhunagar Bus Stand Parking', 14, 'available'),
('Virudhunagar Bus Stand Parking', 15, 'available'),
('Virudhunagar Bus Stand Parking', 16, 'available'),
('Virudhunagar Bus Stand Parking', 17, 'available'),
('Virudhunagar Bus Stand Parking', 18, 'available'),
('Virudhunagar Bus Stand Parking', 19, 'available'),
('Virudhunagar Bus Stand Parking', 20, 'available'),
('Virudhunagar Bus Stand Parking', 21, 'available'),
('Virudhunagar Bus Stand Parking', 22, 'available'),
('Virudhunagar Bus Stand Parking', 23, 'available'),
('Virudhunagar Bus Stand Parking', 24, 'available'),
('Virudhunagar Bus Stand Parking', 25, 'available');

-- Sivakasi Railway Station Parking
INSERT INTO parking_slots (location, slot_number, status) VALUES
('Sivakasi Railway Station Parking', 1, 'available'),
('Sivakasi Railway Station Parking', 2, 'available'),
('Sivakasi Railway Station Parking', 3, 'available'),
('Sivakasi Railway Station Parking', 4, 'available'),
('Sivakasi Railway Station Parking', 5, 'available'),
('Sivakasi Railway Station Parking', 6, 'available'),
('Sivakasi Railway Station Parking', 7, 'available'),
('Sivakasi Railway Station Parking', 8, 'available'),
('Sivakasi Railway Station Parking', 9, 'available'),
('Sivakasi Railway Station Parking', 10, 'available'),
('Sivakasi Railway Station Parking', 11, 'available'),
('Sivakasi Railway Station Parking', 12, 'available'),
('Sivakasi Railway Station Parking', 13, 'available'),
('Sivakasi Railway Station Parking', 14, 'available'),
('Sivakasi Railway Station Parking', 15, 'available'),
('Sivakasi Railway Station Parking', 16, 'available'),
('Sivakasi Railway Station Parking', 17, 'available'),
('Sivakasi Railway Station Parking', 18, 'available'),
('Sivakasi Railway Station Parking', 19, 'available'),
('Sivakasi Railway Station Parking', 20, 'available'),
('Sivakasi Railway Station Parking', 21, 'available'),
('Sivakasi Railway Station Parking', 22, 'available'),
('Sivakasi Railway Station Parking', 23, 'available'),
('Sivakasi Railway Station Parking', 24, 'available'),
('Sivakasi Railway Station Parking', 25, 'available');

-- Virudhunagar Railway Station Parking
INSERT INTO parking_slots (location, slot_number, status) VALUES
('Virudhunagar Railway Station Parking', 1, 'available'),
('Virudhunagar Railway Station Parking', 2, 'available'),
('Virudhunagar Railway Station Parking', 3, 'available'),
('Virudhunagar Railway Station Parking', 4, 'available'),
('Virudhunagar Railway Station Parking', 5, 'available'),
('Virudhunagar Railway Station Parking', 6, 'available'),
('Virudhunagar Railway Station Parking', 7, 'available'),
('Virudhunagar Railway Station Parking', 8, 'available'),
('Virudhunagar Railway Station Parking', 9, 'available'),
('Virudhunagar Railway Station Parking', 10, 'available'),
('Virudhunagar Railway Station Parking', 11, 'available'),
('Virudhunagar Railway Station Parking', 12, 'available'),
('Virudhunagar Railway Station Parking', 13, 'available'),
('Virudhunagar Railway Station Parking', 14, 'available'),
('Virudhunagar Railway Station Parking', 15, 'available'),
('Virudhunagar Railway Station Parking', 16, 'available'),
('Virudhunagar Railway Station Parking', 17, 'available'),
('Virudhunagar Railway Station Parking', 18, 'available'),
('Virudhunagar Railway Station Parking', 19, 'available'),
('Virudhunagar Railway Station Parking', 20, 'available'),
('Virudhunagar Railway Station Parking', 21, 'available'),
('Virudhunagar Railway Station Parking', 22, 'available'),
('Virudhunagar Railway Station Parking', 23, 'available'),
('Virudhunagar Railway Station Parking', 24, 'available'),
('Virudhunagar Railway Station Parking', 25, 'available');
----------------------------------------------------------------------------------------

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    car_number VARCHAR(20) NOT NULL,
    license_number VARCHAR(50) NOT NULL,
    aadhaar_number VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
***********************
ALTER TABLE users 
ADD COLUMN phone VARCHAR(20) NOT NULL AFTER name,
ADD COLUMN car_number VARCHAR(20) NOT NULL,
ADD COLUMN license_number VARCHAR(50) NOT NULL,
ADD COLUMN aadhaar_number VARCHAR(20) NOT NULL;


------------------------------------------------------------------------------------------
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    slot_id INT NOT NULL,
    days INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('pending', 'paid') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (slot_id) REFERENCES parking_slots(id)
);
------------------------------------------------------
