<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['booking_id'])) {
    die("Booking ID missing from session.");
}

include 'db_connect.php';

$booking_id = intval($_SESSION['booking_id']);

// Fetch booking + user + slot + location details
$stmt = $conn->prepare("SELECT 
                            b.*, 
                            u.name, u.phone, u.car_number, 
                            s.slot_number, s.location_name, s.id AS slot_id 
                        FROM bookings b 
                        JOIN users u ON b.user_id = u.id 
                        JOIN parking_slots s ON b.slot_id = s.id 
                        WHERE b.id = ? 
                        LIMIT 1");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Booking not found.");
}

$booking = $result->fetch_assoc();

$name = $booking['name'];
$phone = $booking['phone'];
$car_number = $booking['car_number'];
$days = $booking['days'];
$amount = $booking['amount'];
$slot_id = $booking['slot_id'];
$slot_number = $booking['slot_number'];
$location_name = $booking['location_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay via QR Code</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .payment-container {
            max-width: 450px;
            width: 90%;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.15);
        }
        table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background: #007bff;
            color: white;
            border-radius: 5px 5px 0 0;
        }
        td {
            background: #f9f9f9;
        }
        .qr-image {
            width: 220px;
            height: 220px;
            margin: 15px auto;
            display: block;
        }
        .form-container {
            margin-top: 15px;
        }
        input {
            padding: 10px;
            width: 100%;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 12px;
            background: green;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
            border-radius: 5px;
            font-weight: bold;
        }
        button:hover {
            background: darkgreen;
        }
        .note {
            color: #555;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>

<body>

    <div class="payment-container">
        <h2>Pay ₹<?php echo htmlspecialchars($amount); ?> for your parking</h2>

        <table>
            <tr><th>Name</th><td><?php echo htmlspecialchars($name); ?></td></tr>
            <tr><th>Phone</th><td><?php echo htmlspecialchars($phone); ?></td></tr>
            <tr><th>Car Number</th><td><?php echo htmlspecialchars($car_number); ?></td></tr>
            <tr><th>Parking Days</th><td><?php echo htmlspecialchars($days); ?> days</td></tr>
            <tr><th>Total Amount</th><td>₹<?php echo htmlspecialchars($amount); ?></td></tr>
            <tr><th>Location</th><td><?php echo htmlspecialchars($location_name); ?></td></tr>
            <tr><th>Slot Number</th><td><?php echo htmlspecialchars($slot_number); ?></td></tr>
        </table>

        <img src="images/upi_qr.png" alt="Scan to Pay QR Code" class="qr-image">
        <p class="note">Scan this QR code to pay via UPI (Static)</p>

        <div class="form-container">
            <form action="verify_payment.php" method="POST">
                <input type="text" name="utr_number" placeholder="Enter UTR/Transaction ID" required>
                <input type="hidden" name="slot_id" value="<?php echo htmlspecialchars($slot_id); ?>">
                <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($booking_id); ?>">
                <button type="submit" name="submit">Verify Payment</button>
            </form>
        </div>
    </div>

</body>
</html>
