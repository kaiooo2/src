<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>About Us - Parking Booking System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f9f9f9;
        }
        header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        h2 {
            color: #007bff;
        }
        p {
            line-height: 1.6;
        }
        .home-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .home-btn:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>

    <header>
        <h1>About Our Parking System</h1>
    </header>

    <div class="container">
        <h2>Welcome to Our Smart Parking Booking Platform</h2>
        <p>
            Our system allows users to easily book parking slots online, saving time and avoiding the hassle of finding a space manually.
            We aim to make parking management more efficient by providing real-time slot availability, secure payments, and instant booking confirmations.
        </p>
        <p>
            Key features of our system include:
            <ul>
                <li>Easy online booking & management</li>
                <li>Secure UPI payment integration</li>
                <li>Admin panel for real-time slot monitoring</li>
                <li>Automated bill generation and download</li>
            </ul>
        </p>
        <p>
            Our mission is to simplify urban parking and enhance user convenience.
        </p>

        <a href="home.php" class="home-btn">Back to Home</a>
    </div>

</body>

</html>
