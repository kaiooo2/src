<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

if (!isset($_GET['slot_id']) || !is_numeric($_GET['slot_id'])) {
    die("Invalid slot ID.");
}

$slot_id = intval($_GET['slot_id']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $name = $conn->real_escape_string(trim($_POST['name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $car_number = $conn->real_escape_string(trim($_POST['car_number']));
    $license_number = $conn->real_escape_string(trim($_POST['license_number']));
    $aadhaar_number = $conn->real_escape_string(trim($_POST['aadhaar_number']));
    $days = intval($_POST['days']);
    $total_amount = $days * 200;

    // Basic validation
    if (strlen($phone) != 10 || !is_numeric($phone)) {
        die("Invalid phone number. Must be 10 digits.");
    }
    if (strlen($aadhaar_number) != 12 || !is_numeric($aadhaar_number)) {
        die("Invalid Aadhaar number. Must be 12 digits.");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email address.");
    }
    if ($days <= 0) {
        die("Number of days must be at least 1.");
    }

    // Insert or get user ID
    $check_user = $conn->query("SELECT id FROM users WHERE phone = '$phone'");

    if ($check_user->num_rows > 0) {
        $user_id = $check_user->fetch_assoc()['id'];
    } else {
        $conn->query("INSERT INTO users (name, email, phone, car_number, license_number, aadhaar_number) 
                      VALUES ('$name', '$email', '$phone', '$car_number', '$license_number', '$aadhaar_number')");
        $user_id = $conn->insert_id;
    }

    // Insert booking
    $conn->query("INSERT INTO bookings (user_id, slot_id, days, amount, payment_status) 
                  VALUES ('$user_id', '$slot_id', '$days', '$total_amount', 'pending')");

    $booking_id = $conn->insert_id;

    if ($booking_id) {
        // Mark slot as occupied
        $conn->query("UPDATE parking_slots SET status='occupied' WHERE id='$slot_id'");

        $_SESSION['booking_id'] = $booking_id;

        header("Location: payment.php");
        exit();
    } else {
        die("Booking failed. Please try again.");
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Booking Details</title>
    <link rel="stylesheet" href="css/user.css">
</head>

<body>
    <header>
        <h2>Enter Your Details for Parking</h2>
    </header>

    <form action="" method="POST">
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Phone Number (10 digits):</label>
    <input type="text" name="phone" maxlength="10" pattern="\d{10}" required>

    <label>Car Number:</label>
    <input type="text" name="car_number" required>

    <label>License Number:</label>
    <input type="text" name="license_number" required>

    <label>Aadhaar Number (12 digits):</label>
    <input type="text" name="aadhaar_number" maxlength="12" pattern="\d{12}" required>

    <label>Days to Park:</label>
    <input type="number" name="days" min="1" required>

    <p>Parking Cost: ₹200 per day</p>

    <button type="submit">Proceed to Payment</button>
</form>

</body>

</html>
